$(function(){
    $(window).scroll(function(){
    	if($(this).scrollTop() >= 750){
        	addeffect('.s2left h2','slideInLeft','slideOutLeft')
        	addeffect('.s2left div','slideInUp','slideOutDown')
		}
    });
})