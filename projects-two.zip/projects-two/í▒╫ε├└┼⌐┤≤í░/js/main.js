var addeffect=function(obj,addclass,removeclass){
	$(obj).removeClass(removeclass)
	$(obj).addClass('animated')
	$(obj).addClass(addclass)
	$(obj).css({
		'opacity':'1'
	})
}
var backeffect=function(obj,removeclass,addclass){
	$(obj).removeClass(removeclass)
	$(obj).addClass(addclass)
}
$(function(){
    $(window).scroll(function(){
    	if($(this).scrollTop() >= 0){
        	addeffect('.s1h1','slideInDown','slideOutUp')
		}
    });
})