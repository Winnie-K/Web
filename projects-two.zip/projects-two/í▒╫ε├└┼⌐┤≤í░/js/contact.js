$(function(){
    $(window).scroll(function(){
    	if($(this).scrollTop() >= 700){
        	addeffect('.s2left','slideInLeft','slideOutLeft')
			addeffect('.s2right','slideInRight','slideOutRight')
		}
    	if($(this).scrollTop() >= 1000){
        	addeffect('.section3>p','slideInLeft','slideOutLeft')
			addeffect('.section3 h2','slideInUp','slideOutDown')
        	addeffect('.section3>iframe','fadeIn','fadeOut')
		}
    });
})