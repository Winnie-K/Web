$(function(){
    $(window).scroll(function(){
    	if($(this).scrollTop() >= 550){
        	addeffect('.color','slideInDown','slideOutUp')
        	addeffect('.s1r_img','slideInRight','slideOutRight')
		}
    	if($(this).scrollTop() >= 750){
			addeffect('#line','ani') 
			addeffect('#word','ani1')       	
		}
    });
})