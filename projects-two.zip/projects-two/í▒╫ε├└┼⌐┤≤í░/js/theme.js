$(function(){
    $(window).scroll(function(){
    	if($(this).scrollTop() >= 1500){
        	addeffect('.s3div','slideInRight','slideOutRight')
        	addeffect('.div1','slideInUp','slideOutDown')
		}
    });
})