$(".dot>li>a").eq(0).click(function(){
	$("html,body").animate({scrollTop:$("#section1").offset().top},500);
})
$(".dot>li>a").eq(1).click(function(){
	$("html,body").animate({scrollTop:$("#section2").offset().top},500);
})
$(".dot>li>a").eq(2).click(function(){
	$("html,body").animate({scrollTop:$("#section3").offset().top},500);
})
$(".dot>li>a").eq(3).click(function(){
	$("html,body").animate({scrollTop:$("#section4").offset().top},500);
})
$(function(){
    $(window).scroll(function(){
    	var addeffect3_1=function(obj,addclass,removeclass){
    		$(obj).removeClass(removeclass)
    		$(obj).addClass('animated')
    		$(obj).addClass(addclass)
    		$(obj).css({
				'opacity':'0.5'
			})
    	}
    	var addeffect3_2=function(obj,addclass,removeclass){
    		$(obj).removeClass(removeclass)
    		$(obj).addClass('animated')
    		$(obj).addClass(addclass)
    		$(obj).css({
				'opacity':'0.1'
			})
    	}
    	var addeffect3_3=function(obj,addclass,removeclass){
    		$(obj).removeClass(removeclass)
    		$(obj).addClass('animated')
    		$(obj).addClass(addclass)
    		$(obj).css({
				'opacity':'0.6'
			})
    	}
        if($(this).scrollTop() <= 600){   
			addeffect('.sh1','lightSpeedIn','lightSpeedOut')
			addeffect('.simg1','bounceInRight','bounceOutRight')
			backeffect('.div2','bounceIn','bounceOut')
			backeffect('.sp2','slideInDown','slideOutUp')
			backeffect('.sh2','slideInDown','slideOutUp')
        	backeffect('.simg2','slideInLeft','slideOutLeft')
        }
		if($(this).scrollTop() >= 600&&$(this).scrollTop()<=1000){
			backeffect('.sh1','lightSpeedIn','lightSpeedOut')
        	backeffect('.simg1','bounceInRight','bounceOutRight');
        	addeffect('.simg2','slideInLeft','slideOutLeft')
			addeffect('.sh2','slideInDown','slideOutUp')
        }
		if($(this).scrollTop() >= 1000&&$(this).scrollTop()<=1400){
			addeffect('.div2','bounceIn','bounceOut');
			addeffect('.sp2','slideInDown','slideOutUp')
			backeffect('.sul3 li','slideInRight','slideOutRight')
		}
		if($(this).scrollTop() >= 1400&&$(this).scrollTop()<=1600){
        	backeffect('.simg2','slideInLeft','slideOutLeft')
			backeffect('.div2','bounceIn','bounceOut');
			backeffect('.sp2','slideInDown','slideOutUp')
			backeffect('.sh2','slideInDown','slideOutUp')
			
		}
		if($(this).scrollTop() >= 1400&&$(this).scrollTop()<=1600){
        	backeffect('.simg2','slideInLeft','slideOutLeft')
			backeffect('.div2','bounceIn','bounceOut');
			backeffect('.sp2','slideInDown','slideOutUp')
			backeffect('.sh2','slideInDown','slideOutUp')
			backeffect('.fromleft','slideInLeft','slideOutLeft')
			backeffect('.simg3','slideInRight','slideOutRight')
			addeffect3_1('.sul3 li','slideInRight','slideOutRight')
			backeffect('.sh3-1','slideInDown','slideOutUp')
			backeffect('.sdiv3','slideInLeft','slideOutLeft')
			backeffect('.sh3','slideInLeft','slideOutLeft')
		}
		if($(this).scrollTop() >= 1600&&$(this).scrollTop()<=1800){
			addeffect('.fromleft','slideInLeft','slideOutLeft')
			addeffect3_2('.sdiv3','slideInLeft','slideOutLeft')
			addeffect3_3('.sh3','slideInLeft','slideOutLeft')
			addeffect('.simg3','slideInRight','slideOutRight')
			addeffect('.sh3-1','slideInDown','slideOutUp')
			backeffect('.otherimg','slideInDown','slideOutUp')
			backeffect('.centerimg','slideInUp','slideOutDown')
		}
		if($(this).scrollTop() >= 2200&&$(this).scrollTop()<=2450){
			backeffect('.fromleft','slideInLeft','slideOutLeft')
			backeffect('.sdiv3','slideInLeft','slideOutLeft')
			backeffect('.sh3','slideInLeft','slideOutLeft')
			backeffect('.simg3','slideInRight','slideOutRight')
			addeffect('.otherimg','slideInDown','slideOutUp')
			addeffect('.centerimg','slideInUp','slideOutDown')
			backeffect('.centerp','slideInDown','slideOutUp')
			backeffect('.otherp','slideInUp','slideOutDown')
		}
		if($(this).scrollTop() >= 2450){
			addeffect('.centerp','slideInDown','slideOutUp')
			addeffect('.otherp','slideInUp','slideOutDown')
		}
    });
    $('.otherimg').hover(function(){
    	$(this).removeClass("animated");
    })
    $('.centerimg').hover(function(){
    	$(this).removeClass("animated");
    })
    
})