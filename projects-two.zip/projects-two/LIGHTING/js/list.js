function query() {
	$.ajax({
		type: "POST",
		url: "QueryServlet",
		dataType: "json", 
		success: function(msg) {
			for(var i in msg.users) {
				addRow(msg.users[i].a,msg.users[i].h4,msg.users[i].item_price,msg.users[i].pric1,msg.users[i].disc)
			}
		}
	}); 
}


var pro = [
{ "a":"images/p1.jpg" , "h4":"Gates", "item_price":"12313","pric1":"dvx","disc":"bgbvgbb "},
{ "a":"images/p1.jpg" , "h4":"Gatffes", "item_price":"bggf","pric1":"y65yg","disc":"grtg5 "},
{ "a":"images/p1.jpg" , "h4":"Gathhes", "item_price":"4356","pric1":"j76u","disc":"btyfh8 " }
];

function foo(){
	for(var i in pro) {
			addRow(pro[i].a,pro[i].h4,pro[i].item_price,pro[i].pric1,pro[i].a,pro[i].disc)
		}
}

addRow=function(a,h4, item_price,pric1,disc) {	
	$("#all #all-product").last().after($("#all-product").clone())
	$("#all #all-product").last().find("img").attr("src",a);
	$("#all #all-product").last().find("#h4").text(h4)
	$("#all #all-product").last().find(".item_price").text(item_price)
	$("#all #all-product").last().find(".pric1").text(pric1)
	$("#all #all-product").last().find(".disc").text(disc)
	$("#all-product ").last().removeAttr('id')
} 