$(function() {
	$('#frm1').validate({
		//debug : true, 只会校验表单不会提交表单
		onkeyup: false,
		/*取消键盘监听校验*/
		/*当所有的表单校验通过之后执行提交的功能*/
		submitHandler: function(form) {
			var datas = $(form).serializeJSON();
			//删除了datas中json对象的pwdagin的属性
			delete datas['pwdagin'];
			//采用ajax形式发送
			$.ajax({
				url: 'regist.do',
				type: "post",
				data: JSON.stringify(datas),
				contentType: "application/json;charset=utf-8",
				success: function() {
					location.href = 'loginview.do';
				}
			});
		},

		errorPlacement: function(error, element) {
			error.appendTo(element.parent().next());
		},
		rules: {
			username: {
				required: true,
				/*发送ajax请求校验用户名是否存在:服务器直接响应true或者false*/
				remote: {
					url: "checkusername.do",
					type: "post",
					data: {
						username: function() {
							return $('#username').val();
						}
					}
				}
			},
			/*name值*/
			email: {
				required: true,
				email: true,
				remote: {
					url: "checkemail.do",
					type: "post",
					data: {
						username: function() {
							return $('#email').val();
						}
					}
				}

			},
			pwd: {
				required: true,
				minlength: 3
			},
			pwdagin: {
				equalTo: '#pwd1'
			}

		},
		messages: {
			username: {
				required: "用户名必须填写",
				remote: jQuery.validator.format("{0} 被占用")

			},
			email: {
				required: "邮箱必须填写",
				email: "邮箱格式错误",
				remote: jQuery.validator.format("{0} 被占用")
			},
			pwd: {
				required: "密码必须填写",
				minlength: "长度不能少于3位"
			},
			pwdagin: {
				equalTo: "重复密码不正确"
			},
		},
		/*设置成功的消息*/
		success: function(label) {
			// set &nbsp; as text for IE
			label.html("&nbsp;").addClass("checked");
			label.text('ok');
			console.log("okkkkkk")
		}
	});
});