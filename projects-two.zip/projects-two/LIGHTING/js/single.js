function query() {
	$.ajax({
		type: "POST",
		url: "QueryServlet",
		dataType: "json",
		success: function(msg) {
			for(var i in msg.users) {
				addRow(msg.users[i].img_0, msg.users[i].img_1, msg.users[i].img_2, msg.users[i].h4, msg.users[i].item_price, msg.users[i].para, msg.users[i].li_0, msg.users[i].li_1, msg.users[i].li_2, msg.users[i].li_3)
			}
		}
	});
}

var pro = [{
	"img_0": "images/si.jpg",
	"img_1": "images/si2.jpg",
	"img_2": "images/si3.jpg",
	"h4": "Gates",
	"item_price": "$ 500.00",
	"para": "Lorem ipsum dolor sit amet,",
	"li_0": "- Brand :",
	"li_1": "- Dimensions :",
	"li_2": "- Color : ",
	"li_3": "- Material "
}];

function foo() {
	for(var i in pro) {
		addRow(pro[i].img_0, pro[i].img_1, pro[i].img_2, pro[i].h4, pro[i].para, pro[i].item_price, pro[i].li_0, pro[i].li_1, pro[i].li_2, pro[i].li_3)
	}
}

addRow = function(img_0, img_1, img_2, h4, para, item_price, li_0, li_1, li_2, li_3) {
	$("#all #all-product").after($("#all-product").clone())
	$("#all #all-product").last().find(".img-responsive").eq(0).attr("src", img_0);
//	console.log($("#all #all-product").last().find(".img-responsive").eq(0))
	$("#all #all-product").last().find(".img-responsive").eq(1).attr("src", img_1);
	$("#all #all-product").last().find(".img-responsive").eq(2).attr("src", img_2);
	$("#all #all-product").last().find("#h4").text(h4)
	$("#all #all-product").last().find(".item_price").text(item_price)
	$("#all #all-product").last().find(".para").text(para)
	$("#all #all-product").last().find("#li").eq(0).text(li_0)
	$("#all #all-product").last().find("#li").eq(1).text(li_1)
	$("#all #all-product").last().find("#li").eq(2).text(li_2)
	$("#all #all-product").last().find("#li").eq(3).text(li_3)
	$("#all-product ").last().removeAttr('id')
}