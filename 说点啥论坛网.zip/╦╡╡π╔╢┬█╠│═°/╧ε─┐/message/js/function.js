function selecttext(v) {
	var object = document.getElementsByName(v);
	object[0].select(); //设置文本被选中
	console.log(111)
}
function user_check(v){
	var object=document.getElementsByName('username')
	if(v==''){
//		alert('username不能为空')
	}else if(object[0].value.length>32){
		alert('username长度不能超过32')
	}
}
//123
function pw_check(){
	var object=document.getElementsByName('password')
	console.log(object)
	if(object[0].value.length<6){
		alert('password长度不能小于6')
	}else if(object[0].value.length>32){
		alert('password长度不能超过32')
	}
}
//function email_check(v){
//	if(v==''){
//		alert('email不能为空')
//	}
//}
function Confirm(v){
	var pw=document.getElementsByName('password')
	if(pw.innerHTML!=v){
		alert('两次输入的密码不一致')
	}else{
		con.log(222)
	}
}
function con_check(v){
	var object=document.getElementsByName('content')
	
	if(object[0].value.length>6000){
		alert('文章内容长度不能大于2000')
	}
}
function title_check(v){
	var object=document.getElementsByName('title')
	
	if(v==''){
		alert('标题不能为空')
	}else if(object[0].value.length>45){
		alert('标题长度不能超过15')
	}
}