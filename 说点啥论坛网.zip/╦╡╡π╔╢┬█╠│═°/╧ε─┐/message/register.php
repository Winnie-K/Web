<?php
require'init.php';

?>
<!doctype html>
<html lang="zh">

	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script type="text/javascript" src="js/function.js"></script>
		<title>register</title>
		<!--<link rel="stylesheet" type="text/css" href="css/styles.css">-->
		<style type="text/css">
			* {
				box-sizing: border-box;
				/*宽度包括padding和border*/
				margin: 0;
				padding: 0;
				font-weight: 300;
				pointer-events: none;
				
			}
			
			.title {
				text-align: center;
				margin: 50px 0;
				font-family: "微软雅黑";
				font-size: 20px;
				font-weight: bold;
				color: white;
			}
			a{
				color: deepskyblue;
				font-size: 40px;
				text-decoration: none;
				z-index: 100;
				pointer-events: auto;
				cursor: pointer;
			}
			body {
				font-family: "微软雅黑";
				color: white;
				font-weight: 300;
			}
			/*修改提示文字的样式，根据游览器有所不同*/
			
			body ::-webkit-input-placeholder {
				/* WebKit browsers */
				font-family: "微软雅黑";
				color: white;
				font-weight: bold;
			}
			
			body :-moz-placeholder {
				/* Mozilla Firefox 4 to 18 */
				font-family: "微软雅黑";
				color: white;
				opacity: 1;
				font-weight: bold;
			}
			
			body ::-moz-placeholder {
				/* Mozilla Firefox 19+ */
				font-family: "微软雅黑";
				color: white;
				opacity: 1;
				font-weight: bold;
			}
			
			body :-ms-input-placeholder {
				/* Internet Explorer 10+ */
				font-family: "微软雅黑";
				color: white;
				font-weight: bold;
			}
			
			.wrapper {
				background: #0A3FAF;
				background: -webkit-linear-gradient(top left, #0A3FAF 0%, #6802A3 100%);
				background: linear-gradient(to bottom right, #0A3FAF 0%, #6802A3 100%);
				opacity: 0.8;
				position: absolute;
				width: 100%;
				height: 100%;
				overflow: hidden;
			}
			
			.container {
				max-width: 600px;
				margin: 0 auto;
				padding: 80px 0;
				height: 400px;
				text-align: center;
				pointer-events: auto;
			}
			
			.container h1 {
				font-size: 40px;
				-webkit-transition-duration: 1s;
				/*过渡时间*/
				transition-duration: 1s;
				-webkit-transition-timing-function: ease;
				/*慢快慢速度过渡效果*/
				transition-timing-function: ease;
				font-weight: 200;
				z-index: 2;
			}
			
			form {
				padding: 20px 0;
				position: relative;
				z-index: 2;
				pointer-events: auto;
				/*元素的堆叠顺序(前后)*/
			}
			
			form input {
				pointer-events: auto;
				
				-webkit-appearance: none;
				-moz-appearance: none;
				appearance: none;
				outline: 0;
				border: 1px solid rgba(255, 255, 255, 0.4);
				background-color: rgba(255, 255, 255, 0.2);
				width: 250px;
				border-radius: 3px;
				padding: 10px 15px;
				margin: 0 auto 10px auto;
				display: block;
				/*改变元素显示，变为块级元素，元素前带有换行*/
				text-align: center;
				font-size: 18px;
				color: white;
				-webkit-transition-duration: 0.25s;
				transition-duration: 0.25s;
				font-weight: 300;
			}
			
			form input:hover {
				background-color: rgba(255, 255, 255, 0.4);
			}
			
			form input:focus {
				background-color: white;
				width: 300px;
				color: #FEAE47;
			}
			
			form button {
				pointer-events: auto;
				
				-webkit-appearance: none;
				-moz-appearance: none;
				appearance: none;
				outline: 0;
				background-color: white;
				border: 0;
				padding: 10px 15px;
				color: #FEAE47;
				border-radius: 3px;
				width: 250px;
				cursor: pointer;
				font-size: 18px;
				-webkit-transition-duration: 0.25s;
				transition-duration: 0.25s;
			}
			
			form button:hover {
				background-color: #f5f7f9;
			}
			
			.bg-bubbles {
				position: absolute;
				top: 0;
				left: 0;
				width: 100%;
				height: 100%;
				z-index: 1;
			}
			
			.bg-bubbles li {
				position: absolute;
				list-style: none;
				display: block;
				width: 4px;
				height: 4px;
				border-radius: 50%;
				top: -10px;
				background: #FFFFFF;
				box-shadow: 0 0 5px 5px rgba(255, 255, 255, 0.3);
				-webkit-animation: square 5s infinite;
				animation: square 5s infinite;
				-webkit-transition-timing-function: linear;
				transition-timing-function: linear;
			}
			
			.bg-bubbles li:after {
				content: '';
				display: block;
				/*top: 0px;
	left: 4px;*/
				/*border: 0px solid #fff;*/
				border-style: solid;
				border-width: 2px 90px 2px 90px;
				border-color: transparent transparent transparent rgba(255, 255, 255, 0.3);
				transform: rotate(-45deg);
				transform-origin: 0% 0%;
			}
			
			.bg-bubbles li:nth-child(1) {
				left: 10%;
			}
			
			.bg-bubbles li:nth-child(2) {
				left: 20%;
				-webkit-animation-delay: 2s;
				/*延迟2秒开始动画*/
				-moz-animation-delay: 2s;
				animation-delay: 2s;
				-webkit-animation-duration: 8s;
				/*规定动画完成的时间*/
				-moz-animation-duration: 8s;
				animation-duration: 8s;
			}
			
			.bg-bubbles li:nth-child(3) {
				left: 30%;
				-webkit-animation-delay: 4s;
				-moz-animation-delay: 4s;
				animation-delay: 4s;
			}
			
			.bg-bubbles li:nth-child(4) {
				left: 40%;
				-webkit-animation-duration: 7s;
				-moz-animation-duration: 7s;
				animation-duration: 7s;
			}
			
			.bg-bubbles li:nth-child(5) {
				left: 50%;
			}
			
			.bg-bubbles li:nth-child(6) {
				left: 60%;
				-webkit-animation-delay: 3s;
				-moz-animation-delay: 3s;
				animation-delay: 3s;
			}
			
			.bg-bubbles li:nth-child(7) {
				left: 70%;
				-webkit-animation-delay: 4s;
				-moz-animation-delay: 4s;
				animation-delay: 4s;
			}
			
			.bg-bubbles li:nth-child(8) {
				left: 80%;
				-webkit-animation-delay: 2s;
				-moz-animation-delay: 2s;
				animation-delay: 2s;
				-webkit-animation-duration: 6s;
				-moz-animation-duration: 6s;
				animation-duration: 6s;
			}
			
			.bg-bubbles li:nth-child(9) {
				left: 90%;
				-webkit-animation-delay: 2s;
				-moz-animation-delay: 2s;
				animation-delay: 2s;
				-webkit-animation-duration: 7s;
				-moz-animation-duration: 7s;
				animation-duration: 7s;
			}
			
			.bg-bubbles li:nth-child(10) {
				left: 100%;
				-webkit-animation-delay: 5s;
				-moz-animation-delay: 5s;
				animation-delay: 5s;
			}
			
			.bg-bubbles li:nth-child(11) {
				left: 100%;
				top: 30%;
			}
			
			.bg-bubbles li:nth-child(12) {
				left: 105%;
				top: 45%;
				-webkit-animation-delay: 1s;
				-moz-animation-delay: 1s;
				animation-delay: 1s;
			}
			
			@-webkit-keyframes square {
				0% {
					-webkit-transform: translate(0, 0);
					transform: translateY(0, 0);
				}
				100% {
					-webkit-transform: translate(-900px, 900px);
					transform: translate(-900px, 900px);
				}
			}
			
			@keyframes square {
				0% {
					-webkit-transform: translate(0, 0);
					transform: translate(0, 0);
				}
				100% {
					-webkit-transform: translate(-900px, 900px);
					transform: translate(-900px, 900px);
				}
			}
		</style>
	</head>

	<body>
		
		<div class="htmleaf-container">
			<div class="wrapper">
				<div class="title">
					<h1><a href="login.php">login</a> or <a href="register.php">register</a></h1>
				</div> 
				<div class="container">
					<h1>Sign up for free</h1>
					<?php

// 判断是否提交注册了
if (isset($_POST['submit'])) {
    // 第一步：简单验证 （如果这步验证都不能通过，就"没资格"去访问数据库，因为访问数据库要资源，时间）
    $username = $_POST['username']; // 这样写取值时更快，而且写起来也简便些
    $password = $_POST['password'];
    $pw_check = $_POST['pw_check'];
    $email = $_POST['email'];
    // 用户名不得为空
    if (empty($username)) {
        skip("用户名不得为空", $_SERVER['PHP_SELF']); // 提示错误信息并跳转会注册页
        die;
    }
    // 用户名必须为有效邮箱（自己上网查）
    if(filter_var($email, FILTER_VALIDATE_EMAIL)==false){
        skip("invalid email:$email \n", $_SERVER['PHP_SELF']);
        die;
    }
    if (empty($email) || empty($email)) {
        skip("邮箱不得为空", $_SERVER['PHP_SELF']);
        die;
    }
    
    // 密码和确认密码不得为空
    if (empty($password) || empty($pw_check)) {
        skip("密码不得为空", $_SERVER['PHP_SELF']);
        die;
    }
    if (strlen($username) > 32) {
        skip("用户名不得多于32个字符", $_SERVER['PHP_SELF']);
        die;
    }
    if (strlen($password) > 32) {
        skip("密码不得多于32个字符", $_SERVER['PHP_SELF']);
        die;
    }
    if (strlen($password) < 6) {
        skip("密码不得少于6个字符", $_SERVER['PHP_SELF']);
        die;
    }
    // 密码和确认密码要一致
    if ($password != $pw_check) {
        skip("密码与确认密码不一致", $_SERVER['PHP_SELF']);
        die;
    }
    // 过滤转义等
    $email = check_input($email);
    // 第二步：数据库验证（确保这个邮箱未被注册）
    $query = "SELECT * FROM user WHERE email='$email'";
    $result = mysqlExecute($conn, $query); // 执行sql语句
    $row = mysqli_fetch_assoc($result); // 取出一行，若存在
    if ($row) { // 若存在数据
        skip("该邮箱已被注册", $_SERVER['PHP_SELF']);
        die;
    }
    // 第三步：插入数据库1
    $password = check_input($password);
    $username = check_input($username);
    $username = mysqli_real_escape_string($conn, $username);    
    $password = mysqli_real_escape_string($conn, $password);
    $email = mysqli_real_escape_string($conn, $email);
    $password = md5($password); // 对密码加密
    $query = "INSERT INTO user (username,password,email) VALUES ('$username','$password','$email')";
    $result = mysqlExecute($conn, $query);
    if ($result) {
        skip('注册成功', 'login.php'); // 注册成功，跳转到登陆页面
    } else {
        skip('数据有误', $_SERVER['PHP_SELF']); // 前面验证做得完善就不会到这步
    }
}
?>
	<form class="form" action="" method="post">
		<input type="text" placeholder="Username" name='username' onblur="user_check(this.value)" onfocus="selecttext('username')">
		<input type="email" placeholder="Email Address" name='email' onblur="email_check(this.value)" onfocus="selecttext('email')">
		<input type="password" placeholder="Password" name='password'onblur="pw_check()" onfocus="selecttext('password')">
		<input type="password" placeholder="Confirm password" name='pw_check'onblur="Confirm(this.value)" onfocus="selecttext('pw_check')">
		<button type="submit" id="login-button" name='submit'>Register</button>
						
	</form>
				</div>

				<ul class="bg-bubbles">
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
				</ul>
			</div>
		</div>
	</body>

</html>